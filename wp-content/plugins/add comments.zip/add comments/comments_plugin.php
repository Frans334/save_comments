<?php
/**
 * Plugin Name:add comments
 * Description: adds comments to external api
 * Author: Frans Marumo
 * version:1.0.0
 * Text Domain: add-comments
 */


